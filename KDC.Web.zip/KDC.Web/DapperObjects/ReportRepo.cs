﻿using KDC.DL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using KDC.Web.DapperObjects;
using Dapper;


namespace KDC.Web.DapperObjects
{
    public class ReportRepo
    {
        
    }
}