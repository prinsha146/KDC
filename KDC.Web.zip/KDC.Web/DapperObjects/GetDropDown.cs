﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Dapper;
using KDC.DL.ViewModel;
using KDC.DL.Models;

namespace KDC.Web.DapperObjects
{
    public class GetDropDown
    {
        public List<Basic> GetVaccinationTypeDDL()
        {

            string query = "select VaccinationTypeId Id, VaccinationTypeName Name from MS_VaccinationType Order by VaccinationTypeName";
            using (var db = DBHelper.GetDbConnection())
            {
                var list = db.Query<Basic>(query).ToList();
                return list;
            }
        }
    }
}