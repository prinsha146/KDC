﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using KDC.DL.ViewModel;
using Dapper;
using KDC.DL.Models;

namespace KDC.Web.DapperObjects
{
    public class LoginRepo
    {
        public SessionVM CheckLogin(string Email, string Password, string returnUrl)
        {
            string query = "select u.UserId, u.FullName, u.Email, u.UserType" +
                " from SC_User u" +
                " where u.Email = '" + Email + "' and u.Password = '" + Password + "' and u.IsDeleted = 0";
            using (var db = DBHelper.GetDbConnection())
            {
                return db.Query<SessionVM>(query).SingleOrDefault();
            }
        }
    }
}