﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using KDC.DL.Models;
using Dapper;
using KDC.Web.DapperObjects;

namespace KDC.Web.DapperObjects
{
    public class CandidateRepo
    {
        public void AddCandidate(CD_Candidate candidate)
        {
            string query = "Insert into CD_Candidate(MedicalCenterId, GccCode, VisaNo, VisaDate, RQNoManPower, GamcaNo, DateOfIssueByKDC_AD," +
                "DateOfIssueByKDC_BS, CandidateName, Address, ContactNo, Gender, DOB_AD, DOB_BS, Height_in_cm, Weight_in_kg," +
                "Nationality, JobProfessionId, PassportNo, PassportDateAD, PassportDateBS, PassportPlaceOfIssue, RecruitingAgencyID," +
                "VisaStampingCountryID, InvoiceNo, Allergy, Others, FingerPrint, FingerPrintRemarks, PhotoScanned, PhotoCamera," +
                "Barcode, CandidateDetailsEnteredBy, CandidateDetailsEnteredDate, LabNoIdThisYear, RightEye, LeftEye, RightEar, LeftEar" +
                ", BloodPressure, Heart, Lungs, Chest, Abdomen, Hernia, Veins, Extermities, Deformities, Skin, Clinical, Cns, Pshychiatry) " +
                "values" +
                "(@MedicalCenterId, @GccCode, @VisaNo, @VisaDate, @RQNoManPower, @GamcaNo, @DateOfIssueByKDC_AD," +
                "@DateOfIssueByKDC_BS, @CandidateName, @Address, @ContactNo, @Gender, @DOB_AD, @DOB_BS, @Height_in_cm, @Weight_in_kg," +
                "@Nationality, @JobProfessionId, @PassportNo, @PassportDateAD, @PassportDateBS, @PassportPlaceOfIssue, @RecruitingAgencyID," +
                "@VisaStampingCountryID, @InvoiceNo, @Allergy, @Others, @FingerPrint, @FingerPrintRemarks, @PhotoScanned, @PhotoCamera," +
                "@Barcode, @CandidateDetailsEnteredBy, @CandidateDetailsEnteredDate, @LabNoIdThisYear, @RightEye, @LeftEye, @RightEar, @LeftEar" +
                ", @BloodPressure, @Heart, @Lungs, @Chest, @Abdomen, @Hernia, @Veins, @Extermities, @Deformities, @Skin, @Clinical, @Cns, @Pshychiatry) ";
            using (var db = DBHelper.GetDbConnection())
            {
                db.Execute(query, candidate);
                db.Dispose();
            }
        }
    }
}