﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using KDC.DL.Models;
using KDC.DL.DapperObjects;

namespace KDC.Web.Controllers
{
    public class FitListController : Controller
    {
        private FitListRepo db = new FitListRepo();
        // GET: FitList
        public ActionResult Index()
        {
            var allcandidate = db.GetAllCandidate();
            return View(allcandidate);
        }

        public ActionResult UnFitCandidate()
        {
            var list = db.GetUnfitCandidateList();
            ViewBag.Failed = list.Count();
            return View(list);
        }

        public ActionResult GetFitStatus(int id)
        {
            var candidate = db.GetCandidateFitStatus(id);
            return View(candidate);
        }

    }
}