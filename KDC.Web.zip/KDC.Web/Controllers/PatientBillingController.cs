﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using KDC.DL.DapperObjects;
using KDC.DL.Models;

namespace KDC.Web.Controllers
{
    public class PatientBillingController : Controller
    {
        PatientBillingRepo db = new PatientBillingRepo();
        GetDropDown ddl = new GetDropDown();
        ams_kdcdb repo = new ams_kdcdb();
        // GET: PatientBilling
        public ActionResult Index()
        {
            var detail = db.GetPatientList();
            return View(detail);
        }

        public ActionResult Create()
        {
            //ViewBag.ServiceId = new SelectList(repo.SV_Service.OrderBy(s => s.ServiceName), "ServiceId", "ServiceName");
            ViewBag.ServiceId = repo.SV_Service.OrderBy(m => m.ServiceName).ToList();
            ViewBag.Address = new SelectList(ddl.GetDistrictDDL(), "Id", "Name");
            ViewBag.ReferrerId = new SelectList(repo.MS_Referer.OrderBy(s => s.RefererName), "RefererId", "RefererName");
            //ViewBag.Rate = db.GetRateAmount(20080124001);
            return View();
        }

        [HttpPost]
        public ActionResult Create(FormCollection collection, string[] hditemindex)
        {
            BL_Patient patient = new BL_Patient();
            try
            {
                int rowcount = hditemindex.Count();
                var i = 1;

                for (i = 1; i <= rowcount; i++)
                {
                    if (i == Convert.ToInt32(hditemindex[i - 1]))
                    {
                        patient.PatientName = collection["PatientName"];
                        patient.Gender = collection["Gender"];
                        patient.Age = Convert.ToInt32(collection["Age"]);
                        patient.Address = collection["Address"];
                        patient.PhoneMobile = collection["PhoneMobile"];
                        patient.ManualNo = collection["ManualNo"];
                        patient.InvoiveNo = collection["InvoiceNo"];
                        patient.InvoiceDate = Convert.ToDateTime(collection["InvoiceDate"]);
                        patient.InvoiveDateBS = collection["InvoiceDateBS"];
                        patient.ReferrerId = Convert.ToInt32(collection["ReferrerId"]);
                        patient.EnteredBy = Convert.ToInt32(Session["UserId"]);
                        patient.EnteredDate = DateTime.Now;
                        patient.LabCode = Convert.ToInt32(collection["LabCode"]);
                        patient.TotalAmount = Convert.ToDecimal(collection["TotalAmount"]);
                        patient.Discount = Convert.ToInt32(collection["Discount"]);
                        patient.Net = Convert.ToDecimal(collection["Net"]);
                        patient.Tender = Convert.ToDecimal(collection["Tender"]);
                        patient.Change = Convert.ToDecimal(collection["Change"]);

                        db.AddPatientBill(patient);
                    }
                }
                return RedirectToAction("Index");

            }
            catch (Exception ex)
            {
                ViewBag.ServiceId = repo.SV_Service.OrderBy(m => m.ServiceName).ToList();
                ViewBag.Address = new SelectList(ddl.GetDistrictDDL(), "Id", "Name");
                ViewBag.ReferrerId = new SelectList(repo.MS_Referer.OrderBy(s => s.RefererName), "RefererId", "RefererName");
                return View();
            }
        }

        public float RateAmount(double id)
        {
            float rate = db.GetRateAmount(id);
            return rate;
        }

        public ActionResult Edit(int id)
        {
            var billing = db.GetPatientBillById(id);
            ViewBag.ServiceId = repo.SV_Service.OrderBy(m => m.ServiceName).ToList();
            ViewBag.Address = new SelectList(ddl.GetDistrictDDL(), "Id", "Name");
            ViewBag.ReferrerId = new SelectList(repo.MS_Referer.OrderBy(s => s.RefererName), "RefererId", "RefererName");
            return View();
        }

        [HttpPost]
        public ActionResult Edit(FormCollection collection, string[] hditemindex)
        {
            BL_Patient patient = new BL_Patient();
            try
            {
                int rowcount = hditemindex.Count();
                var i = 1;

                for (i = 1; i <= rowcount; i++)
                {
                    if (i == Convert.ToInt32(hditemindex[i - 1]))
                    {
                        patient.PatientName = collection["PatientName"];
                        patient.Gender = collection["Gender"];
                        patient.Age = Convert.ToInt32(collection["Age"]);
                        patient.Address = collection["Address"];
                        patient.PhoneMobile = collection["PhoneMobile"];
                        patient.ManualNo = collection["ManualNo"];
                        patient.InvoiveNo = collection["InvoiceNo"];
                        patient.InvoiceDate = Convert.ToDateTime(collection["InvoiceDate"]);
                        patient.InvoiveDateBS = collection["InvoiceDateBS"];
                        patient.ReferrerId = Convert.ToInt32(collection["ReferrerId"]);
                        patient.EnteredBy = Convert.ToInt32(Session["UserId"]);
                        patient.EnteredDate = DateTime.Now;
                        patient.LabCode = Convert.ToInt32(collection["LabCode"]);
                        patient.TotalAmount = Convert.ToDecimal(collection["TotalAmount"]);
                        patient.Discount = Convert.ToInt32(collection["Discount"]);
                        patient.Net = Convert.ToDecimal(collection["Net"]);
                        patient.Tender = Convert.ToDecimal(collection["Tender"]);
                        patient.Change = Convert.ToDecimal(collection["Change"]);

                        db.EditPatientBill(patient);
                    }
                }
                return RedirectToAction("Index");
            }
            catch (Exception e)
            {
                ViewBag.ServiceId = repo.SV_Service.OrderBy(m => m.ServiceName).ToList();
                ViewBag.Address = new SelectList(ddl.GetDistrictDDL(), "Id", "Name");
                ViewBag.ReferrerId = new SelectList(repo.MS_Referer.OrderBy(s => s.RefererName), "RefererId", "RefererName");
                return View();
            }
        }
    }
}