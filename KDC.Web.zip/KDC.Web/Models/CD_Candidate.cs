namespace KDC.Web.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("ams_kdcdb1.CD_Candidate")]
    public partial class CD_Candidate
    {
        [Key]
        public int CandidateID { get; set; }

        public int? MedicalCenterID { get; set; }

        [StringLength(50)]
        public string GccCode { get; set; }

        [StringLength(50)]
        public string GccHMC { get; set; }

        [StringLength(50)]
        public string VisaNo { get; set; }

        [Column(TypeName = "date")]
        public string VisaDate { get; set; }

        [StringLength(50)]
        public string RQNoManpower { get; set; }

        [StringLength(50)]
        public string GamcaNo { get; set; }

        [Column(TypeName = "date")]
        public DateTime? DateOfIssueByKDC_AD { get; set; }

        [StringLength(10)]
        public string DateOfIssueByKDC_BS { get; set; }

        [StringLength(150)]
        public string CandidateName { get; set; }

        public int? Address { get; set; }

        [StringLength(100)]
        public string ContactNo { get; set; }

        [StringLength(1)]
        public string Gender { get; set; }

        [Column(TypeName = "date")]
        public DateTime? DOB_AD { get; set; }

        [StringLength(10)]
        public string DOB_BS { get; set; }

        public decimal? Height_in_cm { get; set; }

        public decimal? Weight_in_kg { get; set; }

        [StringLength(50)]
        public string Nationality { get; set; }

        public int? JobProfessionID { get; set; }

        [StringLength(50)]
        public string PassportNo { get; set; }

        [Column(TypeName = "date")]
        public DateTime? PassportDateAD { get; set; }

        [StringLength(10)]
        public string PassportDateBS { get; set; }

        public int? PassportPlaceOfIssue { get; set; }

        public int? RecruitingAgencyID { get; set; }

        public int? VisaStampingCountryID { get; set; }

        [StringLength(50)]
        public string InvoiceNo { get; set; }

        public bool? Allergy { get; set; }

        [StringLength(50)]
        public string Others { get; set; }

        [Column(TypeName = "ntext")]
        public string FingerPrint { get; set; }

        [StringLength(50)]
        public string FingerPrintRemarks { get; set; }

        [StringLength(50)]
        public string PhotoScanned { get; set; }

        [StringLength(50)]
        public string PhotoCamera { get; set; }

        [StringLength(50)]
        public string Barcode { get; set; }

        public int? CandidateDetailsEnteredBy { get; set; }

        [Column(TypeName = "date")]
        public DateTime? CandidateDetailsEnteredDate { get; set; }

        public int? LabNoIdThisYear { get; set; }

        [StringLength(20)]
        public string RightEye { get; set; }

        [StringLength(20)]
        public string LeftEye { get; set; }

        [StringLength(20)]
        public string RightEar { get; set; }

        [StringLength(20)]
        public string LeftEar { get; set; }

        [StringLength(20)]
        public string BloodPressure { get; set; }

        [StringLength(20)]
        public string Heart { get; set; }

        [StringLength(20)]
        public string Lungs { get; set; }

        [StringLength(20)]
        public string Chest { get; set; }

        [StringLength(20)]
        public string Abdomen { get; set; }

        [StringLength(20)]
        public string Hernia { get; set; }

        [StringLength(20)]
        public string Veins { get; set; }

        [StringLength(20)]
        public string Extermities { get; set; }

        [StringLength(20)]
        public string Deformities { get; set; }

        [StringLength(20)]
        public string Skin { get; set; }

        [StringLength(20)]
        public string Clinical { get; set; }

        [StringLength(20)]
        public string Cns { get; set; }

        [StringLength(20)]
        public string Pshychiatry { get; set; }

        [StringLength(20)]
        public string Hb { get; set; }

        [StringLength(20)]
        public string TC_in_cumm { get; set; }

        [StringLength(20)]
        public string HIV_1_2 { get; set; }

        [StringLength(20)]
        public string HBsAg { get; set; }

        [StringLength(20)]
        public string Anti_HCV { get; set; }

        [StringLength(20)]
        public string TPHA { get; set; }

        [StringLength(20)]
        public string VDRL { get; set; }

        [StringLength(20)]
        public string MP { get; set; }

        [StringLength(20)]
        public string MF { get; set; }

        [StringLength(20)]
        public string Urine_Re_Me { get; set; }

        [StringLength(20)]
        public string Sugar { get; set; }

        [StringLength(20)]
        public string Albumin { get; set; }

        [StringLength(20)]
        public string Stool_RE { get; set; }

        [StringLength(20)]
        public string DC_N { get; set; }

        [StringLength(20)]
        public string DC_L { get; set; }

        [StringLength(20)]
        public string DC_E { get; set; }

        [StringLength(20)]
        public string DC_M { get; set; }

        [StringLength(20)]
        public string DC_B { get; set; }

        [StringLength(20)]
        public string Platelets { get; set; }

        [StringLength(20)]
        public string Sugar_Block { get; set; }

        [StringLength(20)]
        public string Bill_T_Per { get; set; }

        [StringLength(20)]
        public string Albumin_Per { get; set; }

        [StringLength(20)]
        public string Bil_D_Per { get; set; }

        [StringLength(20)]
        public string TPro_Per { get; set; }

        [StringLength(20)]
        public string Alk_Pho_Per { get; set; }

        [StringLength(20)]
        public string Creat_Block { get; set; }

        [StringLength(20)]
        public string SGPT_Per { get; set; }

        [StringLength(20)]
        public string Urea_Per { get; set; }

        [StringLength(20)]
        public string ESR_Per { get; set; }

        [StringLength(20)]
        public string GGT_Per { get; set; }

        [StringLength(20)]
        public string SGOT_Per { get; set; }

        public int? BloodGroup_RH { get; set; }

        [StringLength(20)]
        public string Other { get; set; }

        public bool? Pregnancy { get; set; }

        public int? LabTestEnteredBy { get; set; }

        public DateTime? LabTestEnteredDate { get; set; }

        public DateTime? DateOfVaccination { get; set; }

        public int? VaccinationDataEnteredBy { get; set; }

        public int? EnteredBy { get; set; }

        public DateTime? EnteredDate { get; set; }

        public int? LastUpdatedBy { get; set; }

        public DateTime? LastUpdateDate { get; set; }
    }
}
