namespace KDC.Web.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("ams_kdcdb1.MS_District")]
    public partial class MS_District
    {
        [Key]
        public int DistrictId { get; set; }

        [StringLength(50)]
        public string DistrictName { get; set; }

        public bool? IsDeleted { get; set; }
    }
}
